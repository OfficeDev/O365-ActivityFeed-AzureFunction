# Input bindings are passed in via param block.
param(
    [Parameter(Mandatory=$true)][string]$filePath,
    [Parameter(Mandatory=$true)][string]$fullFileUrl,
    [Parameter(Mandatory=$true)][hashtable]$headerParams
)


# Define Graph API URL and headers
$graphApiUrl = "https://graph.microsoft.com/v1.0"
$headers = $headerParams

# Define Microsoft Graph API Base URL
$graphBaseUrl = "https://graph.microsoft.com/v1.0"

# Extract SharePoint domain, site name, and file path using [uri]
try {
    $uri = [uri]$fullFileUrl
    $domain = $uri.Host
    $segments = $uri.AbsolutePath.TrimStart('/').Split('/')
    if ($segments[0] -eq "sites") {
        $siteName = $segments[1]
        # Handle cases where the document library name may vary
        $libraryName = $segments[2]
        $filePath = ($segments[2..($segments.Length - 1)] -join "/")
    } else {
        Write-Host "Invalid SharePoint URL format. Exiting..."
        exit 1
    }
} catch {
    Write-Host "Error parsing URL: $($_.Exception.Message)"
    exit 1
}

# Step 1: Get Site ID
$siteUrl = "$graphBaseUrl/sites/$($domain):/sites/$siteName"
$siteResponse = Invoke-RestMethod -Uri $siteUrl -Headers $headers -Method Get
$siteID = $siteResponse.id

# Step 2: Get Drive ID
# Step 2: Get the Correct Drive ID based on File Path
$drivesUrl = "$graphBaseUrl/sites/$siteID/drives"
$drivesResponse = Invoke-RestMethod -Uri $drivesUrl -Headers $headers -Method Get
# Find the drive that contains the file (assumes it's the first matching drive)
$driveID = $drivesResponse.value[0].id  # Default to first drive if no filtering is applied

write-host "This is the DriveURL: " $drivesUrl
write-host "This is the response: " $drivesResponse.value

# Step 3: Get File ID
# Remove the document library name from file path if present
$libraryName = $segments[2]
if ($filePath -like "$libraryName/*") {
    $filePath = $filePath.Substring("$libraryName/".Length)
}

# Encode file path for URL
$encodedFilePath = [System.Web.HttpUtility]::UrlPathEncode($filePath)

# Step 3: Get File ID using Full File Path
$fileUrl = "$graphBaseUrl/sites/$siteID/drives/$driveID/root:/$encodedFilePath"
$fileResponse = Invoke-RestMethod -Uri $fileUrl -Headers $headers -Method Get
$fileID = $fileResponse.id

write-host "This is the FileURL: " $fileUrl

# Output the results
Write-Host "Site ID: $siteID"
Write-Host "Drive ID: $driveID"
Write-Host "File ID: $fileID"



function Get-GraphCollection {
    param (
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][hashtable]$Headers
    )
    $allItems = @()
    while ($Url) {
        try {
            $response = Invoke-RestMethod -Uri $Url -Headers $Headers -ErrorAction Stop
            $allItems += $response.value
            $Url = $response.'@odata.nextLink'
        }
        catch {
            Write-Host "Error fetching data: $($_.Exception.Message)"
            break
        }
    }
    return $allItems
}

try {
    $fileactualid = ($FileId -split "_")[-1]
    $fileUrl = "/sites/$SiteId/drive/items/$fileactualid"
    Write-Host "Requesting file object from URL: $graphApiUrl$fileUrl"
    $file = Invoke-RestMethod -Uri "$graphApiUrl$fileUrl" -Headers $headers -ErrorAction Stop

    # Collect file permissions in one pass
    $sharingDetails = @()
    $filePermUrl = "/sites/$SiteId/drive/items/$fileactualid/permissions"
    Write-Host "Requesting direct file permissions from URL: $graphApiUrl$filePermUrl"
    $filePerms = Get-GraphCollection -Url "$graphApiUrl$filePermUrl" -Headers $headers

    $filePerms | ForEach-Object {
        $sharingDetails += $_.grantedToIdentitiesV2.user.email
        $sharingDetails += $_.grantedToV2.user.email
    }

    # Collect all emails without filtering by domain for now
    $matchingEmails = $sharingDetails | Select-Object -Unique

    # Optionally, you can uncomment the following lines to filter by domain in the future
    # $domains = @("hotmail.com", "gmail.com", "yahoo.com", "woodgrove.ms")
    # $matchingEmails = $sharingDetails | Where-Object { $_ -match "@($($domains -join '|'))$" } | Select-Object -Unique

}catch {
    Write-Host "Error: $($_.Exception.Message)"
    $matchingEmails = @()
}
return $matchingEmails