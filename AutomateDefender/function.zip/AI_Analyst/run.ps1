# Input bindings are passed in via param block.
param($Timer)
$useAI=$true

# Initialize variables
$data = @()
$resource = "https://graph.microsoft.com"
$dlpreportmbx = "INCIDENTMAILBOX@YOURDOM.onmicrosoft.com"

# Define policies and their corresponding instructions for AI analysis
$policiesAndInstructions = @(
    @{
        Policy = "Financial Data"
        Instruction = "You are Matilda, a very skilled data security analyst. Assess if the data contains an actual credit card or not based on the context. If it is high to medium ambiguity classify it as low. Add significant weight to how classification has been done based on the DLP Policy Financial Data in the past. If the data clearly contains a single credit card or a personal exchange, classify it as low and close the case. Take into account the deparment of the user and probability of legitimate sharing. You MUST provide a high, med, low answer, indicate it with Risk level: following the assessment such as low (Risk level: low). Do provide a reason for your answer. Keep responses concise (max 1000 characters) and provide a clear, context-driven justification."
        ResolveOnLowRisk = $true
    },
    @{
        Policy = "PII Policy"
        Instruction = "You are Matilda,  a very skilled data security analyst. Assess if the data contains actual Social Security Numbers (SSNs) based on the context. If there is high to medium ambiguity, classify it as low. Add significant weight to how classification has been done based on the DLP Policy PII policy in the past. If the data clearly contains a single SSN or a personal exchange, classify it as low and close the case. You MUST provide a high, medium, or low answer, indicated with Risk level: following the assessment such as low (Risk level: low). Provide a reason for your answer. Keep responses concise (max 1000 characters) and provide a clear, context-driven justification."
        ResolveOnLowRisk = $true
    },
    @{ 
        Policy = "SPO_External"
        Instruction = "You are Matilda, a very skilled data security analyst. Assess if the data contains an actual credit card or not based on the context. If it is high to medium ambiguity classify it as low. Add significant weight to how classification has been done based on the DLP Policy Financial Data in the past, if this is the first incident and it involves more than one credit card make it high. If the data clearly contains a single credit card or a personal exchange, classify it as low and close the case. Take into account the deparment of the user and probability of legitimate sharing. You MUST provide a high, med, low answer, indicate it with Risk level: following the assessment such as low (Risk level: low). Do provide a reason for your answer. Keep responses concise (max 1000 characters) and provide a clear, context-driven justification."
        ResolveOnLowRisk = $true
    }
)

# Authenticate using Managed Identity and get access token for Graph API
$token = (Get-AzAccessToken -ResourceUrl $resource -AsSecureString).Token | ConvertFrom-SecureString -AsPlainText
$headerParams = @{'Authorization' = "Bearer $token"}

# Define OpenAI endpoint and API key
$openAIEndpoint = "https://YOURINSTANCE.cognitiveservices.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-01-01-preview"
$apiKey = "$env:AIKey"

###############################################
# Function to call the AI model for analysis
###############################################
function Analyze-Data {
    param (
        [string]$result,
        [string]$instruction,
        [string]$apiKey,
        [string]$openAIEndpoint
    )

    # Prepare messages payload for AI model
    $messages = @(
        @{ role = "system"; content = $instruction },
        @{ role = "user"; content = "Analyze the following data: $result" }
    )

    # Convert messages to JSON
    $body = @{ messages = $messages; max_tokens = 4000; temperature = 0.2 } | ConvertTo-Json -Depth 10 -Compress
#write-host $body
    # Define headers for API call
    $headers = @{
        "Content-Type" = "application/json"
        "api-key"      = $apiKey
    }

    # Invoke AI model with retry logic for handling 429 errors
    $maxRetries = 5
    $retryCount = 0
    do {
        try {
            $response = Invoke-RestMethod -Uri $openAIEndpoint -Method Post -Headers $headers -Body $body -ContentType "application/json"
            return $response.choices.message.content
        }
        catch {
            if ($_.Exception.Response.StatusCode -eq 429 -and $retryCount -lt $maxRetries) {
                $retryAfter = $_.Exception.Response.Headers.'Retry-After'
                if (-not $retryAfter) { $retryAfter = [math]::Pow(2, $retryCount) }
                Write-Output "Rate limit hit. Retrying after $retryAfter seconds..."
                Start-Sleep -Seconds $retryAfter
                $retryCount++
            }
            else {
                throw $_
            }
        }
    } while ($retryCount -le $maxRetries)
}

###############################################
# Retrieve incidents from Microsoft Graph Security API
###############################################
$startDate = (Get-Date).AddDays(-5).ToString("yyyy-MM-dd")
$url = 'https://graph.microsoft.com/v1.0/security/incidents?$expand=alerts&$filter=createdDateTime ge' + " $startDate"
$incidents = Invoke-RestMethod -Headers $headerParams -Uri $url -Method GET
$data += $incidents.value

# Handle pagination if more incidents exist
while ($incidents.'@odata.nextLink') {
    $incidents = Invoke-RestMethod -Headers $headerParams -Uri $incidents.'@odata.nextLink' -Method GET
    $data += $incidents.value
}

###############################################
# Process each incident and associated alerts
###############################################
foreach ($incident in $data) {
    if ($incident.status -eq "Active") {
    foreach ($alert in $incident.alerts) {
        foreach ($policyInstruction in $policiesAndInstructions) {
            # Check if alert matches policy and is new
            if ($alert.additionaldata.AlertPolicyTitle -like $policyInstruction.Policy -and $alert.status -like "new") {
                $policy = $policyInstruction.Policy
                $instruction = $policyInstruction.Instruction
                $resolveOnLowRisk = $policyInstruction.ResolveOnLowRisk
#write-host $policy
                # Extract message ID and subject from alert evidence
                $messageid = @($alert.evidence.internetmessageid) | Where-Object { $_ -and $_.Trim() -ne '' } | Select-Object -First 1
                $subject = $alert.evidence.subject
            if ($useAI) {
              if ($messageid) {
                # Query DLP mailbox for message content
                if ($policy) {
                    $graphcall = "https://graph.microsoft.com/v1.0/users/$dlpreportmbx/messages?`$search=`"body: Exchange AND body: $messageid AND body: $subject AND Policy body: $policy`""
                    $content = Invoke-RestMethod -Headers $headerParams -Uri $graphcall -Method GET

                    # Extract relevant content using regex
                    if ($content.value[0].body.content -match "Location:.*") {
                        $result = $matches[0]
                        if ($result.Length -gt 20000) { Write-Output "Excessive matches"; continue }
                    } else { Write-Output "No match found"; continue }
                }
              }
            }
#write-host "Alertdisplay: "$alert.evidence.displayName
#write-host "Evidence: " $alert.evidence
                # Extract document path from alert evidence SharePoint
                if ($useAI) {
                if ($alert[0].evidence.displayname -like "Microsoft SharePoint Online" -or $alert[0].evidence.displayname -like "Microsoft OneDrive for Business") {
                    $filePath = $alert[0].evidence.filedetails[1].filePath.TrimEnd("/") + "/"
                    $fullFileUrl = $filePath + $alert[0].evidence.filedetails[1].fileName
                    $fileNameDecoded = [System.Uri]::UnescapeDataString($alert[0].evidence.filedetails[1].fileName)
                    $fileNameWithoutExtension = [System.IO.Path]::GetFileNameWithoutExtension($fileNameDecoded.Split('?')[0])

                # Query DLP mailbox for content
                if ($policy) {
                    $searchQuery = "body:$fileNameWithoutExtension AND body:$($alert[0].evidence.useraccount.userPrincipalname) AND body:$policy"
                    $graphcall = "https://graph.microsoft.com/v1.0/users/$dlpreportmbx/messages?`$search=`"$searchQuery`""
#write-host "This is the graph call: " $graphcall
                    $content = Invoke-RestMethod -Headers $headerParams -Uri $graphcall -Method GET

                    # Verify if the retrieved content contains the full file URL and select the matching item
                    $contentMatch = $content.value | Where-Object { $_.body.content -match [regex]::Escape($fullFileUrl) }
                    if (-not $contentMatch) {
                        Write-Output "Full file URL not found in any content"
                        continue
                    }

                    # Extract relevant content using regex
                    if ($contentmatch.body.content -match "Detected:.*") {
                        $result = $matches[0] + " On top of this we matched $($alert.evidence.count) documents with similar content. The names are $($alert.evidence.filedetails.fileName)"
                        if ($result.Length -gt 20000) { Write-Output "Excessive matches"; continue }
                    } else { Write-Output "No match found"; continue }
                }
            }
        }
            if ($alert[0].evidence.displayname -like "Microsoft SharePoint Online" -or $alert[0].evidence.displayname -like "Microsoft OneDrive for Business") {
                   if ($alert.evidence.displayname -like "Microsoft SharePoint Online") {$users = .\spoperm.ps1 -filePath $filePath -fullFileUrl $fullFileUrl -headerParams $headerParams}
                   if ($alert.evidence.displayname -like "Microsoft OneDrive for Business") {$users = .\odbperm.ps1 -filePath $filePath -fullFileUrl $fullFileUrl -headerParams $headerParams}
                $spodomains = @()
                foreach ($user in $users) {
                    if ($user -match '@') {
                        $domain = $user.Split('@')[1]
                        if (-not ($spodomains -contains $domain)) {
                            $spodomains += $domain
                        }
                    }
                }
            
            }

                    #Get user details.
                    $queryString = "https://graph.microsoft.com/v1.0/users/" + $alert.evidence.useraccount.userPrincipalname + "?`$select=department,state,jobTitle,country"
                    $info = Invoke-RestMethod -Headers $headerParams -Uri $queryString -Method GET -SkipHttpErrorCheck

if ($useAI) {
                    # Summarize user's previous incidents
                    $userIncidents = $data | Where-Object {
                        $_.alerts.evidence.useraccount.userPrincipalName -contains $alert.evidence.useraccount.userPrincipalname
                    }
                    if ($userIncidents) {
                        $incidentSummary = $userIncidents | Group-Object severity, classification, displayName | Select-Object @{
                            Name = 'Severity'; Expression = { $_.Group[0].severity }
                        }, @{
                            Name = 'Classification'; Expression = { $_.Group[0].classification }
                        }, @{
                            Name = 'Title'; Expression = { $_.Group[0].displayName }
                        }, @{
                            Name = 'Count'; Expression = { $_.Count }
                        }
                        $result += "`nSummary of previous incidents this week:`n"
                        foreach ($summary in $incidentSummary) {
                            $result += "Severity: $($summary.Severity), Classification: $($summary.Classification), Title: $($summary.Title), Count: $($summary.Count)`n"
                        }
                    }

                    # Append user details
                    $result += "`nUser Information:`nDepartment: $($info.department)`nState: $($info.state)`nJob Title: $($info.jobTitle)`nCountry: $($info.country)`n"

                    # Clean HTML tags and decode entities
                    $result = ($result -replace '<[^>]+>', '') | ForEach-Object { [System.Net.WebUtility]::HtmlDecode($_) }

                    # Analyze data using AI model
                    $response = Analyze-Data -result $result -instruction $instruction -apiKey $apiKey -openAIEndpoint $openAIEndpoint

                    # Extract risk level from AI response
                    if ($response -match "Risk Level:\s*(\w+)") { $riskLevel = $matches[1] }
    }
                    $domains = @()
                        foreach ($emailaddress in $incident.alerts.evidence.recipientEmailaddress) {
                            if (($domains.count -lt 10) -and ($emailaddress -match '@')) {
                                $parts = $emailaddress.Split('@')
                                if ($parts.count -ge 2) {
                                    $domain = $parts[1]
                                    if (-not ($domains -contains $domain)) {
                                        $domains += $domain
                                    }
                                }
                            }
                        }
                        $customdomTags += $domains
                    if ($spodomains) {$customdomTags += @($spodomains)}   
                    if ($info.department) {$customdomTags += @($info.department)}

#If AI is not used use existing severity or customize based on Domains.
if (!$useAI) {$riskLevel = $incident.severity}

                    # Update incident based on risk level
                    if ($riskLevel -in @('high', 'medium')) {
                        # If additional tags exist, add them
                        $customTags = @($incident.customTags)
                        $customTagsString = $customdomTags  # Example additional tag
                        if ($customTagsString) {
                            $customTags += $customTagsString
                        }

                        $body = @{customTags = $customTags; status = "inProgress"; severity = $riskLevel.ToLower() } | ConvertTo-Json -Depth 10
                        Invoke-RestMethod -Headers $headerParams -Uri "https://graph.microsoft.com/v1.0/security/incidents/$($incident.id)" -Method patch -Body $body -ContentType "application/json"
                        # Add AI comment
                       if ($useAI) {
                        $commentBody = @{ "@odata.type" = "microsoft.graph.security.alertComment"; comment = $response.Substring(0, [Math]::Min(999, $response.Length)) } | ConvertTo-Json -Depth 10
#                        write host "I do not think it is here: " $commentBody
                        Invoke-RestMethod -Headers $headerParams -Uri "https://graph.microsoft.com/v1.0/security/incidents/$($incident.id)/comments" -Method post -Body $commentBody -ContentType "application/json"
                       }
                    } elseif ($riskLevel -eq 'low') {
                        # Resolve incident if low risk
                        # If additional tags exist, add them
                        $customTags = @($incident.customTags)
                        $customTagsString = $customdomTags  # Example additional tag
                        if ($customTagsString) {
                            $customTags += $customTagsString
                        }
     if ($resolveOnLowRisk) {
                        if (!$useAI) {$body = @{ customTags = $customTags; resolvingComment = "Incident kept open for investigation"; classification = "inProgress"; status = "resolved"; severity = $riskLevel } | ConvertTo-Json -Depth 10}
                        if ($useAI) {$body = @{ customTags = $customTags; resolvingComment = $response.Substring(0, [Math]::Min(999, $response.Length)); classification = "falsePositive"; status = "resolved"; severity = $riskLevel } | ConvertTo-Json -Depth 10}
                        Invoke-RestMethod -Headers $headerParams -Uri "https://graph.microsoft.com/v1.0/security/incidents/$($incident.id)" -Method patch -Body $body -ContentType "application/json"
                    } elseif (!$resolveOnLowRisk) {
                        $body = @{customTags = $customTags; status = "inProgress"; severity = $riskLevel.ToLower() } | ConvertTo-Json -Depth 10
                        Invoke-RestMethod -Headers $headerParams -Uri "https://graph.microsoft.com/v1.0/security/incidents/$($incident.id)" -Method patch -Body $body -ContentType "application/json"
                        # Add AI comment
                       if ($useAI) {
                        $commentBody = @{ "@odata.type" = "microsoft.graph.security.alertComment"; comment = $response.Substring(0, [Math]::Min(999, $response.Length)) } | ConvertTo-Json -Depth 10
                        Invoke-RestMethod -Headers $headerParams -Uri "https://graph.microsoft.com/v1.0/security/incidents/$($incident.id)/comments" -Method post -Body $commentBody -ContentType "application/json"
                       }
                    }
                }

Clear-Variable -Name result, messageid, subject, content, riskLevel, customTagsString, customTags, customdomTags,body, alert
if ($info) {Clear-Variable info}
if ($commentBody) {Clear-Variable commentBody}
if ($filepath) {Clear-Variable filePath,fullFileUrl}
            }
        }
    }
}
}
