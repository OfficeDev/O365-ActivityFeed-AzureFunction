param(
    [Parameter(Mandatory=$true)][string]$fullFileUrl,
    [Parameter(Mandatory=$true)][hashtable]$headerParams,
    [Parameter(Mandatory=$true)][string]$filePath
)

$graphApiUrl = "https://graph.microsoft.com/v1.0"
$headers = $headerParams

# Extract site URL and file path from the provided URL
try {
    $uri = [uri]$fullFileUrl
    $pathSegments = $uri.AbsolutePath.Trim('/').Split('/')

    # Extract site path and file path
    $sitePath = ($pathSegments[0..($pathSegments.Length - 3)] -join '/')
    $filePath = ($pathSegments[($pathSegments.Length - 2)..($pathSegments.Length - 1)] -join '/')

    # Get Site ID
    $siteUrl = "$graphApiUrl/sites/$($uri.Host):/$sitePath"
    $siteResponse = Invoke-RestMethod -Uri $siteUrl -Headers $headers -Method Get
    $siteId = $siteResponse.id

    # Get File ID
    # Remove the first library from the file path
    $filePathSegments = $filePath -split '/'
    $filePathWithoutLibrary = ($filePathSegments | Select-Object -Skip 1) -join '/'
    $encodedFilePath = [System.Web.HttpUtility]::UrlPathEncode($filePathWithoutLibrary)
    $fileUrl = "$graphApiUrl/sites/$siteId/drive/root:/$encodedFilePath"
    $fileResponse = Invoke-RestMethod -Uri $fileUrl -Headers $headers -Method Get
    $fileId = $fileResponse.id

    Write-Host "Site ID: $siteId"
    Write-Host "File ID: $fileId"

    
    # Get all sublibraries
    $librariesUrl = "$graphApiUrl/sites/$siteId/drive/root/children"
    $librariesResponse = Invoke-RestMethod -Uri $librariesUrl -Headers $headers -Method Get

    $matchingEmails = @()

    foreach ($library in $librariesResponse.value) {
        try {
            # Check if the current library matches the first segment of the file path
            if ($library.name -eq $filePathSegments[0]) {
                # Get the file path for the current library
                $libraryFilePath = "$library.name/$filePathWithoutLibrary"
                $encodedLibraryFilePath = [System.Web.HttpUtility]::UrlPathEncode($libraryFilePath)
                $fileUrl = "$graphApiUrl/sites/$siteId/drive/root:/$encodedLibraryFilePath"
                $fileResponse = Invoke-RestMethod -Uri $fileUrl -Headers $headers -Method Get
                $fileId = $fileResponse.id

                # Get permissions for the file in the current library
                $permissionsUrl = "$graphApiUrl/sites/$siteId/drive/items/$fileId/permissions"
                $permissionsResponse = Invoke-RestMethod -Uri $permissionsUrl -Headers $headers -Method Get

                # Extract emails from permissions
                foreach ($perm in $permissionsResponse.value) {
                    $matchingEmails += $perm.grantedToV2.user.email
                    $perm.grantedToIdentitiesV2 | ForEach-Object {
                        $matchingEmails += $_.user.email
                    }
                }
            }
        }
        catch {
            Write-Host "Error processing library $($library.name): $($_.Exception.Message)"
        }
    }

    # Include permissions set directly on the file
    try {
        $directPermissionsUrl = "$graphApiUrl/sites/$siteId/drive/items/$fileId/permissions"
        $directPermissionsResponse = Invoke-RestMethod -Uri $directPermissionsUrl -Headers $headers -Method Get

        foreach ($perm in $directPermissionsResponse.value) {
            $matchingEmails += $perm.grantedToV2.user.email
            $perm.grantedToIdentitiesV2 | ForEach-Object {
                $matchingEmails += $_.user.email
            }
        }
    }
    catch {
        Write-Host "Error retrieving direct permissions for file: $($_.Exception.Message)"
    }

    # Filter unique and non-empty emails
    $matchingEmails = $matchingEmails | Where-Object { $_ } | Select-Object -Unique
}
catch {
    Write-Host "Error: $($_.Exception.Message)"
    $matchingEmails = @()
}

return $matchingEmails